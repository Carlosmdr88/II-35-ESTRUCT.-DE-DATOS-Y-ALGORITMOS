/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto1;

/**
 *
 * @author carlo
 */
public class Operacion {

    private int valor;
    private String tipo;

    public Operacion(int valor, String tipo) {
        this.valor = valor;
        this.tipo = tipo;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Operacion inversa() {

        if (tipo.equals("+")) {
            return new Operacion(valor, "-");
        } else {
            return new Operacion(valor, "+");
        }

    }

    @Override
    public String toString() {
        return tipo + valor;
    }

}
