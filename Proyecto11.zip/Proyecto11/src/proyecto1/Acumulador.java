package proyecto1;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author carlo
 */
public class Acumulador {

    private int total;
    private ArrayList<Operacion> undoStack;
    private ArrayList<Operacion> redoStack;

    public Acumulador() {
        total = 0;
        undoStack = new ArrayList<>();
        redoStack = new ArrayList<>();
    }

    public int getTotal() {
        return total;
    }

    public ArrayList<Operacion> getUndoStack() {
        return undoStack;
    }

    public ArrayList<Operacion> getRedoStack() {
        return redoStack;
    }

    // Aplica una operación nueva
    public void aplicar(Operacion op) {

        undoStack.add(op);

        // Cada operación nueva elimina el historial de redo
        redoStack.clear();

        if (op.getTipo().equals("+")) {
            total += op.getValor();
        } else {
            total -= op.getValor();
        }

    }

    // Deshacer
    public void undo() {

        if (undoStack.isEmpty()) {
            JOptionPane.showMessageDialog(null,
                    "No hay operaciones para deshacer.");
            return;
        }

        Operacion ultima = undoStack.remove(undoStack.size() - 1);

        if (ultima.getTipo().equals("+")) {
            total -= ultima.getValor();
        } else {
            total += ultima.getValor();
        }

        redoStack.add(ultima);

    }

    // Rehacer
    public void redo() {

        if (redoStack.isEmpty()) {
            JOptionPane.showMessageDialog(null,
                    "No hay operaciones para rehacer.");
            return;
        }

        Operacion ultima = redoStack.remove(redoStack.size() - 1);

        if (ultima.getTipo().equals("+")) {
            total += ultima.getValor();
        } else {
            total -= ultima.getValor();
        }

        undoStack.add(ultima);

    }

    public void estado() {

        String mensaje = "";

        mensaje += "ACUMULADOR: " + total + "\n\n";

        mensaje += "UNDO\n";
        for (int i = 0; i < undoStack.size(); i++) {

            if (i == 0) {
                mensaje += "Fondo -> ";
            }

            mensaje += undoStack.get(i);

            if (i == undoStack.size() - 1) {
                mensaje += " <- Tope";
            }

            mensaje += "\n";
        }

        mensaje += "\nREDO\n";

        for (int i = 0; i < redoStack.size(); i++) {

            if (i == 0) {
                mensaje += "Fondo -> ";
            }

            mensaje += redoStack.get(i);

            if (i == redoStack.size() - 1) {
                mensaje += " <- Tope";
            }

            mensaje += "\n";
        }

        JOptionPane.showMessageDialog(null, mensaje);

    }



}