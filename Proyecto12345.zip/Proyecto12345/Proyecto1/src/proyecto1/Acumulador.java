/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto1;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author carlo
 * */
public class Acumulador {
    private int total;
    ArrayList<Integer> undoStack;
    ArrayList<Integer> redoStack; // Esta la ocupamos para el Redo

    public Acumulador() {
        undoStack = new ArrayList<>();
        redoStack = new ArrayList<>(); // Solo la inicializamos aquí para que no dé error
    }

    public int getTotal() {
        return total;
    }

    public ArrayList<Integer> getUndoStack() {
        return undoStack;
    }

    public ArrayList<Integer> getRedoStack() {
        return redoStack;
    }

    public void undo() {
        // 1. Validar si la lista está vacía para que no se caiga el programa
        if (undoStack.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay nada que deshacer");
            return; 
        }

        // 2. Sacar el último número de undo (El Tope)
        int posicionUltimo = undoStack.size() - 1;
        int valor = undoStack.remove(posicionUltimo);

        // 3. Pasarlo a redo
        redoStack.add(valor);

        // 4. Recalcular el total con tu mismo for
        total = 0;
        for (Integer v : undoStack) {
            total += v;
        }
    }

    public void redo() {
        // 1. Validar si hay algo en redo para rehacer
        if (redoStack.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay nada que rehacer");
            return;
        }

        // 2. Sacar el último número de redo
        int posicionUltimo = redoStack.size() - 1;
        int valor = redoStack.remove(posicionUltimo);

        // 3. Devolverlo a undo
        undoStack.add(valor);

        // 4. Recalcular el total con tu mismo for
        total = 0;
        for (Integer v : undoStack) {
            total += v;
        }
    }

    // puede ser positivo o negativo
    public void aplicar(int valor) {
        undoStack.add(valor);
        
        // REGLA: Si el usuario mete un número nuevo, el redo se limpia
        redoStack.clear();

        total = 0;
        for (Integer v : undoStack) {
            total += v;
        }
        System.out.println("Total:" + total);
        System.out.println("undoStack:" + undoStack);
    }

    public void estado() {
        // Usamos texto plano y directo como lo tenías, solo sumando las variables
        JOptionPane.showMessageDialog(null,
                "UNDO (Historial): " + undoStack + "\n" + 
                "REDO (Deshechos): " + redoStack + "\n" +
                "Total Neto: " + total);
    }
}
