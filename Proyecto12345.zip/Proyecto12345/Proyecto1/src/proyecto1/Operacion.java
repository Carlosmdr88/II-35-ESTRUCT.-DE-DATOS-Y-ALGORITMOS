/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto1;

/**
 *
 * @author carlo
 */
public class Operacion {
    private int valor;
    private String tipo; // "+" o "-"

    public Operacion(int valor, String tipo) {
        this.valor = valor;
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }

    public int getValor() {
        return valor;
    }
    
    public Operacion inversa(){
        // Creamos una variable para el tipo inverso
        String tipoInverso = "";
        
        // Si la operación actual es suma, la inversa es resta
        if (this.tipo.equals("+")) {
            tipoInverso = "-";
        } else {
            tipoInverso = "+";
        }
        
        // Creamos y retornamos la nueva operación con el mismo valor pero signo contrario
        Operacion opInversa = new Operacion(this.valor, tipoInverso);
        return opInversa;
    }
}